// ============================================================
// Phase A patch — ggml/src/ggml-cuda/common.cuh
// Target: NVCC 10.2 / C++14 (no `if constexpr`, no `std::is_same_v`)
// ============================================================

#include <type_traits>

// ------------------------------------------------------------
// 1) Replacement for line 571: C++17 fold-expression is_any<>
// ------------------------------------------------------------
template<typename T, typename... Ts>
struct is_any;

template<typename T, typename U, typename... Ts>
struct is_any<T, U, Ts...>
    : std::integral_constant<bool, std::is_same<T, U>::value || is_any<T, Ts...>::value> {};

template<typename T>
struct is_any<T> : std::false_type {};


// ------------------------------------------------------------
// 2) Replacement for lines 578–612: if constexpr chains
//
// NOTE: The bodies below are placeholders. This document did not
// include the original per-type branch logic from common.cuh, so
// each op() below must be filled in with the exact code that lived
// inside the corresponding `if constexpr (std::is_same_v<T, ...>)`
// block in your source tree before this compiles correctly.
// Do a side-by-side diff against the original file when porting.
// ------------------------------------------------------------

// Base (undefined) template — every T used at the call site must
// have an explicit specialization below, or you'll get a linker/
// "incomplete type" error at compile time, which is what you want
// (it flags any type you forgot to port).
template<typename T>
struct ggml_cuda_type_ops;

// float specialization
template<>
struct ggml_cuda_type_ops<float> {
    static __device__ __forceinline__ void op(float * dst, const float * src, int idx) {
        // [PORT ME]: original float-branch body from common.cuh
        dst[idx] = src[idx];
    }
};

// half specialization
template<>
struct ggml_cuda_type_ops<half> {
    static __device__ __forceinline__ void op(half * dst, const half * src, int idx) {
        // [PORT ME]: original half-branch body from common.cuh
        dst[idx] = src[idx];
    }
};

// half2 specialization
template<>
struct ggml_cuda_type_ops<half2> {
    static __device__ __forceinline__ void op(half2 * dst, const half2 * src, int idx) {
        // [PORT ME]: original half2-branch body from common.cuh
        dst[idx] = src[idx];
    }
};

// Wrapper replacing the function that used to contain `if constexpr`
template<typename T>
__device__ __forceinline__ void ggml_cuda_execute_op(T * dst, const T * src, int idx) {
    ggml_cuda_type_ops<T>::op(dst, src, idx);
}

// ------------------------------------------------------------
// 3) Lines 789, 796: if constexpr(alignment != 0) / if constexpr(nb_per_cpy == 1)
//
// These are value-based (not type-based) branches, so the cleanest
// C++14 fix is usually a template<bool> partial specialization or a
// preprocessor #if, rather than tag dispatch. Sketch:
// ------------------------------------------------------------
template<int alignment>
struct ggml_cuda_alignment_ops;

template<>
struct ggml_cuda_alignment_ops<0> {
    // [PORT ME]: body for alignment == 0 case
    static __device__ __forceinline__ void run() {}
};

// Fallback for any nonzero alignment — replace with the real
// nonzero-alignment logic from the original branch.
template<int alignment>
struct ggml_cuda_alignment_ops {
    static __device__ __forceinline__ void run() {
        // [PORT ME]: body for alignment != 0 case
    }
};
