#include "common.cuh"
#include "fattn.cuh"

// Flash attention stubs for SM 5.3 / CUDA 10.2
// Flash attention requires SM 7.0+ (Volta) tensor cores.
// These stubs allow the rest of the code to link without flash attention support.

void ggml_cuda_flash_attn_ext(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    (void)ctx; (void)dst;
    GGML_ABORT("flash attention not available on SM 5.3 / CUDA 10.2");
}

bool ggml_cuda_flash_attn_ext_supported(int device, const ggml_tensor * dst) {
    (void)device; (void)dst;
    return false;
}
