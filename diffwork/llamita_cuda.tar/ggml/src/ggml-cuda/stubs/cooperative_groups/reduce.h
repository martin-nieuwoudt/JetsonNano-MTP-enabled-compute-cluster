// Stub for cooperative_groups/reduce.h
// Not available in CUDA 10.2. Flash attention (which uses it) is disabled.
